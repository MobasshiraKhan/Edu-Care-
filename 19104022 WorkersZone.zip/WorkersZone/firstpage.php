<!DOCTYPE html>
<html>
 <head>
    <style>
        li{
            display: inline-block;
            padding: 10px;}
        a{
            color:#F7FE13;
        }


      #particles-js {
       

      }
     </style>
 </head>
<body>
  <div> 
   <div >
   

     <!-- Header Section -->
       <table width="100%" style="border-collapse:collapse;">
           <tr>
            <td colspan="2" style="background-color:#B9E8F7; text-align: center;">
            

            <h3 style="font-size: 22px; color: #581845;"><marquee >Workers Zone</marquee> </h3>
               
            </td>
         </tr>


   <!-- Nav Section -->
          <tr>
                        <td colspan="2" style="background-color:#394593 ;font-size: 22px;text-align: center;">
                <ul>
                             
                 
                <li><a href="login.php">Log in </a></li>  
                <li><a href="signup.php">Sign up </a></li>  
                <li><a href="aboutus.html">About us </a></li>  
                
                         
                
               
                <li><a href="workersdashboard.html">Workers Dashboard</a></li>
                         

</p>            

            </ul>
            </td>
          </tr>
   <!-- Main Section -->
          <tr>
             <td style="background-color:#e6e6fa; width:50%; height: 490px; text-align: center;">
             
             <img src="download.jpg" alt="Good Morning "/>                
              </td>
              <td  style="background-color:#0c0b0c; height: 580px; width:300px;padding:20;margin: 20;">
     <div id="particles-js" style="padding:0;margin: 0; width: 100%;
     height:500px;
     background-repeat: no-repeat;
     background-size: cover;
     background-position: center center;
    background-image: url(38.png);"></div>               
              </td>             
 </tr>
     <!-- Footer Section -->
           <tr>
             <td colspan="2" style="background-color:#2e2e2e; text-align: center;">
                <p style="color:#f08080">©<strong>Pick Your Service</strong></p>

                
            </td>
          </tr>
    </table>

    </div>
 <script src="particles.js"></script>
    <script src="app.js"></script>
 </body>
</html>