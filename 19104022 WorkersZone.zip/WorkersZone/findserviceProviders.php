<?php 
$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "workers";
 $conn = new mysqli($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit'])){
  $Worker = $_POST['worker'];
  $area = $_POST['area'];
  if(!empty($Worker)){
      $query = "INSERT INTO selection (Worker,area) VALUES('$Worker','$area')";
      $result = $conn->query($query);
      if($result){
        echo "Inserted successfully";
        header('Location:Payment.php');
      }  
    }
  }

  // if(isset($_POST['submit'])){
  //   $area = $_POST['area'];
  //   if(!empty($area)){
  //       $query = "INSERT INTO selection (area) VALUES('$area')";
  //       $result = $conn->query($query);
  //       if($result){
  //         echo "Area is inserted successfully";
  //       }  
  //     }
  //   }


?>





<body>
    <div class="header finisher-header" style="width: 100%; height: 800px;">
     




      <div> 
        <div >
          <!-- Header Section -->
          <form action="" method="post">
            <table width="50%" style="border-collapse:collapse;"<table align="center">
                <tr>
                 <td colspan="2" style="background-color:#0b030d; text-align: center;">
                     <h3 style="font-size: 22px; color: #f5f914;">Find Service provider </h3>
                 </td>
              </tr>
       
     
     </p>            
     </ul>
     </td>
     </tr>
     <!-- Main Section -->
     <tr>

        <td style="background-color:#e6e6fa; width:50%; height: 490px; text-align: center;">
          <img src="ce.jpg" alt="Good Morning "/>
          <!-- <form >
            <label for="Working category">Choose a Worker:</label>
            <select name="Category" id="Category">
              
              <option value="Plamber">Plamber</option>
              <option value="Electrition">Electrition</option>
              <option value="Nurse">Nurse</option>
              <option value="Painter">Painter</option>
              <option value="Tv mechanic">Tv mechanic</option>
              <option value="Washroom Cleaner">Washroom  Cleaner</option>
              <option value="Cleaner">Cleaner</option>
              
            </select>
            <br><br>
            
          </form> 
                              -->
                              <label for="Working category">Choose a Worker:</label>                            
<select name="worker">
                  
                  <option value="Plamber">Plamber</option>
                  <option value="Electrition">Electrition</option>
                  <option value="Nurse">Nurse</option>
                  <option value="Painter">Painter</option>
                  <option value="Tv mechanic">Tv mechanic</option>
                  <option value="Washroom Cleaner">Washroom  Cleaner</option>
                  <option value="Cleaner">Cleaner</option>
                  

</select>

          </td>
          <td  style="background-color:#ffc1ff; height: 150px; width:80px;padding:0;margin: 0;">
            <div id="particles-js" style="padding:0;margin: 0; width: 70%;
            height:330px;
            background-repeat: no-repeat;
            background-size: cover;
            background-position: right ;
           background-image: url(30.jpg);"></div>
           <label for="Choose area">Choose area:</label>
           <select name="area">
                    <option value="Doyrampur">Doyrampur</option>
                    <option value="Bagatipara">Bagatipara</option>
                    <option value="Misripara">Misripara</option>
                    <option value="Parapur">Parapur</option>
                    <option value="Tanic">Tanic</option>
                    <option value="Waner">Waner</option>
                    <option value="Cooner">Cooner</option>
                    <option value="Bcdpara">Bcdpara</option>
                  </select>


            <!-- <form >
          
              <label for="Choose area">Choose area:</label>
              <select name="Natore" id="Natore">
                <option value="Doyrampur">Doyrampur</option>
                <option value="Bagatipara">Bagatipara</option>
                <option value="Misripara">Misripara</option>
                <option value="Parapur">Parapur</option>
                <option value="Tanic">Tanic</option>
                <option value="Waner">Waner</option>
                <option value="Cooner">Cooner</option>
                <option value="Bcdpara">Bcdpara</option>
              </select>
                <br><br>
                
                
             
            </form>          -->
           
                     </td>         

                    
                    </tr>
                    <!-- Footer Section -->
                          <tr>
                            <td colspan="2" style="background-color:#12120e; text-align: center;">
                            <input type="submit" style="color:#ff1010" name="submit">
                             
                             <!-- <li ><a href="Payment.html" style="color:#ff1010"><strong>Submit</strong> </a></li>  -->
                                <p style="color:#fcf003 ">©<strong>Pick Your Service</strong></p>
                           </td>
                         </tr>
                   </table>
                   
</form>
               
                   </div>
                









    </div>
    <script src="finisher-header.es5.min.js" type="text/javascript"></script>
    <script type="text/javascript">
new FinisherHeader({
  "count": 55,
  "size": {
    "min": 15,
    "max": 135,
    "pulse": 0.3
  },
  "speed": {
    "x": {
      "min": 0,
      "max": 0.2
    },
    "y": {
      "min": 0,
      "max": 0.4
    }
  },
  "colors": {
    "background": "#620C6E",
    "particles": [
      "#ffe960",
      "#87ddfe",
      "#8481ff",
      "#fc7bfc",
      "#e2ffa5"
    ]
  },
  "blending": "screen",
  "opacity": {
    "center": 0,
    "edge": 0.7
  },
  "skew": 0.0,
  "shapes": [
    "c"
  ]
});
</script>
  </body>