<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!--<title> Responsiive workers Dashboard </title>-->
    <link rel="stylesheet" href="wd.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
     
      <span class="logo_name"><marquee >**WorkersZone**</marquee ></span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="#" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">My taking service list</span>
          </a>
        </li>
        
        
        
        
       
        <li class="Back">
          <a href="firstpage.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Back</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">My profile</span>
      </div>
      
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">-->
        <span class="admin_name">Athena Khan</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic"><marquee >Total Order</marquee ></div>
            <div class="number">10</div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bx-cart-alt cart'></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total works</div>
            <div class="number"><marquee >8</marquee ></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bxs-cart-add cart two' ></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total invest</div>
            <div class="number"><marquee >12,000 taka</marquee ></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bx-cart cart three' ></i>
        </div>
        
      </div>

      <div class="sales-boxes " >
        <div class="recent-sales box">
          <div class="title">  My ordered services</div>
          <div class="sales-details">
            <ul class="details">
              <li class="topic">Created_at</li>
              <li><a href="#">02 Jan 2021</a></li>
              <li><a href="#">28 Feb 2021</a></li>
              <li><a href="#">02 March 2021</a></li>
              <li><a href="#">08 March 2021</a></li>
              <li><a href="#">06 March 2021</a></li>
              <li><a href="#">02 April 2021</a></li>
              <li><a href="#">02 April 2021</a></li>
              <li><a href="#">15 May 2021</a></li>
              <li><a href="#">03 June 2021</a></li>
              <li><a href="#">02 June 2021</a></li>
              <li><a href="#">05 July 2021</a></li>
              <li><a href="#">02 July 2021</a></li>
              <li><a href="#">02 August 2021</a></li>
            </ul>
            <ul class="details">
            <li class="topic">Worker</li>
            <li><a href="#">Nurse</a></li>
            <li><a href="#">Nurse</a></li>
            <li><a href="#"> Electrition</a></li>
            <li class="#">Plumber</li>
            <li><a href="#"> Electrition</a></li>
            <li><a href="#">Painter</a></li>
            <li class="#">Plumber</li>
            <li class="#">Plumber</li>
            <li><a href="#">Painter</a></li>
            <li><a href="#">Painter</a></li>
             <li><a href="#">Nurse</a></li>
             
             <li><a href="#"> Electrition</a></li>
            
             <li><a href="#">Painter</a></li>
          </ul>
          <ul class="details">
            <li class="topic">Work done</li>
            <li><a href="#">Delivered</a></li>
            <li><a href="#">Pending</a></li>
            <li><a href="#">Returned</a></li>
            <li><a href="#">Delivered</a></li>
            <li><a href="#">Pending</a></li>
            <li><a href="#">Returned</a></li>
            <li><a href="#">Delivered</a></li>
             <li><a href="#">Pending</a></li>
            <li><a href="#">Delivered</a></li>
            <li><a href="#">Returned</a></li>
            <li><a href="#">Delivered</a></li>
            <li><a href="#">Pending</a></li>
            <li><a href="#">Returned</a></li>
          </ul>
          <ul class="details">
            <li class="topic">Invest</li>
            <li><a href="#">1000</a></li>
            <li><a href="#">200</a></li>
            <li><a href="#">3000</a></li>
            <li><a href="#">1000</a></li>
            <li><a href="#">200</a></li>
            <li><a href="#">400</a></li>
            <li><a href="#">600</a></li>
             <li><a href="#">111</a></li>
             <li><a href="#">100</a></li>
             <li><a href="#">222</a></li>
            <li><a href="#">333</a></li>
            <li><a href="#">222</a></li>
            <li><a href="#">111</a></li>
          </ul>
          </div>
          <div class="button">
            <a href="#">See All</a>
          </div>
        </div>
       
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>

