<form action="" method="post">
<select name="Worker">
                  
                  <option value="Plamber">Plamber</option>
                  <option value="Electrition">Electrition</option>
                  <option value="Nurse">Nurse</option>
                  <option value="Painter">Painter</option>
                  <option value="Tv mechanic">Tv mechanic</option>
                  <option value="Washroom Cleaner">Washroom  Cleaner</option>
                  <option value="Cleaner">Cleaner</option>
                  

</select>
<select name="area">
                    <option value="Doyrampur">Doyrampur</option>
                    <option value="Bagatipara">Bagatipara</option>
                    <option value="Misripara">Misripara</option>
                    <option value="Parapur">Parapur</option>
                    <option value="Tanic">Tanic</option>
                    <option value="Waner">Waner</option>
                    <option value="Cooner">Cooner</option>
                    <option value="Bcdpara">Bcdpara</option>
                  </select>
<input type="submit" name="submit">

</form>