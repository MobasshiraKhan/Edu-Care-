<?php 
if(isset($_POST['submit'])){
  $Worker = $_POST['Worker'];
  if(!empty($Worker)){
      $query = "INSERT INTO selection (Worker) VALUES('$Worker')";
      $result = $conn->query($query);
      if($result){
        echo "Workers is inserted successfully";
      }  
    }
  }

  if(isset($_POST['submit'])){
    $area = $_POST['area'];
    if(!empty($area)){
        $query = "INSERT INTO selection (area) VALUES('$area')";
        $result = $conn->query($query);
        if($result){
          echo "Area is inserted successfully";
        }  
      }
    }


?>