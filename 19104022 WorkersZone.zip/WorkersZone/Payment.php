<?php
$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "workers";
 $conn = new mysqli($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
    
    $sql = "insert into payment(name,email,adress,city)values('$name','$email','$address','$city')"; 

if ($conn->query($sql)) {
	echo "";
} else {
	echo "Error: ".$sql."<br>".$conn->error;
}

$conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- custom css file link  -->
    <link rel="stylesheet" href="st.css">

</head>
<body>

<div class="container">

    <form action="" method="post">

        <div class="row">

            <div class="col">

                <h3 class="title">billing address</h3>
                
                <div class="inputBox">
                    <span>full name :</span>
                    <input name="name" type="text" placeholder="***">
                </div>
                <div class="inputBox">
                    <span>email :</span>
                    <input type="email" name="email" placeholder="**@**.com">
                </div>
                <div class="inputBox">
                    <span>address :</span>
                    <input type="text" name="address" placeholder="****">
                </div>
                <div class="inputBox">
                    <span>city :</span>
                    <input type="text" name="city" placeholder="***">
                </div>
                <div class="flex">
                    <div class="inputBox">
                        <span>state :</span>
                        <input type="text" name="state" placeholder="***">
                    </div>
                    <div class="inputBox">
                        <span>zip code :</span>
                        <input type="text" name="zip" placeholder="***">
                    </div>
                </div>

            </div>

            <div class="col">

                <h3 class="title">payment</h3>

                <div class="inputBox">
                   















                </div>
                <div class="inputBox">
                    <span>name on card :</span>
                    <input type="text" name="nameOnCard" placeholder="****">
                </div>
                <div class="inputBox">
                    <span>credit card number :</span>
                    <input name="cardNumber" type="number" placeholder="*****">
                </div>
                <div class="inputBox">
                    <span>exp month :</span>
                    <input name="expM" type="text" placeholder="****">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>exp year :</span>
                        <input name="expY" type="number" placeholder="****">
                    </div>
                    <div class="inputBox">
                        <span>CVV :</span>
                        <input name="cvv" type="text" placeholder="****">
                    </div>
                </div>

            </div>
    
        </div>

        
        <li><a href="done.html">proceed to checkout </a></li> 
        <li ><a href="firstpage.php">Back to home</a></li>
      
      

    </form>

</div>    
    
</body>
</html>